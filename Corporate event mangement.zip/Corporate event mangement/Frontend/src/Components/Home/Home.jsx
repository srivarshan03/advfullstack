import BannerBackground from "../../Assets/images/event.jpg";
import Navbar from "../Navbar";
import { Link } from "react-router-dom";
import { FiArrowRight } from "react-icons/fi";

const Home = () => {
  return (
    <div className="home-container">
      <Navbar />
      <div className="home-banner-container">
        <div style={{marginTop:100,marginRight:100}} className="home-bannerImage-container">
          <img style={{borderRadius:100}} src={BannerBackground} alt="" />
        </div>
        <div className="home-text-section">
          <h1 className="primary-heading">Welcome to Corporate Symphony</h1>
          <p className="primary-text">
          Are you ready to elevate your skills and excel in the dynamic field of corporate event management?
          </p>
          <Link className="mobile-links" to={"/about"}>
            <button className="secondary-button">
              <>
                About us <FiArrowRight />
              </>
            </button>
          </Link>
        </div>
        <div className="home-image-section">
        </div>
      </div>
    </div>
  );
};

export default Home;
