import { AiFillStar } from "react-icons/ai";

const Testimonial = () => {
  return (
    <div className="work-section-wrapper">
      <div className="work-section-top">
        <p className="primary-subheading">Testimonial</p>
        <h1 style={{textAlign : 'center'}} className="primary-heading">What They Are Saying</h1>
      </div>
      <div className="testimonial-section-bottom">
        {/* <img src={ProfilePic} alt="" /> */}
        <p>
        Working with Corporate Symphony was an absolute pleasure! From the initial planning stages to the execution of our corporate event, every detail was meticulously handled with professionalism and creativity. The team at Corporate Symphony went above and beyond to ensure that our event was not only flawlessly executed but also exceeded our expectations.
        </p>
        <div className="testimonials-stars-container">
          <AiFillStar />
          <AiFillStar />
          <AiFillStar />
          <AiFillStar />
        </div>
        <h2>John Due</h2>
      </div>
    </div>
  );
};

export default Testimonial;
