import Explore from "../../Assets/images/works-bg.png";
import Submit from "../../Assets/images/works-bg1.png";
import Event from "../../Assets/images/works-bg2.png";

const Work = () => {
  const workInfoData = [
    {
      image: Explore,
      title: "Explore Event Options",
      text: "Explore a wide range of event options tailored to suit your corporate needs and objectives. From conferences and seminars to product launches and corporate retreats, we offer a diverse selection of event possibilities.",
    },
    {
      image: Submit,
      title: "Submit Your Event Request",
      text: "Submitting your event request is as easy as a few clicks. Our streamlined process ensures that your request is processed swiftly and efficiently, allowing you to focus on other aspects of your corporate strategy.",
    },
    {
      image: Event,
      title: "Personalized Event Management",
      text: "Experience personalized event management services tailored to your specific requirements. Our team of experts will guide you through every step of the event planning process, ensuring that your vision is brought to life with precision and excellence.",
    },
  ];
  return (
    <div className="work-section-wrapper">
      <div className="work-section-top">
        <p className="primary-subheading">Celebrate Your Success</p>
        <p className="primary-text">Discover the seamless process of corporate event management with Corporate Symphony. From conceptualization to execution, we're here to ensure that your event is a resounding success.</p>
      </div>
      <div className="work-section-bottom">
        {workInfoData.map((data) => (
          <div className="work-section-info" key={data.title}>
            <div className="info-boxes-img-container">
              <img src={data.image} alt={data.title} />
            </div>
            <h2>{data.title}</h2>
            <p>{data.text}</p>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Work;
