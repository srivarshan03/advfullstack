import Footer from "../Components/Footer";
import Navbar from "../Components/Navbar";
import CssBaseline from "@mui/material/CssBaseline";
import Box from "@mui/material/Box";
import TextField from "@mui/material/TextField";
import FormControlLabel from "@mui/material/FormControlLabel";
import Checkbox from "@mui/material/Checkbox";
import Paper from "@mui/material/Paper";
import Grid from "@mui/material/Grid";
import { Link, useNavigate } from "react-router-dom";
import axios from "axios";  
import Typography from "@mui/material/Typography";
import { createTheme, ThemeProvider } from "@mui/material/styles";
import { useState } from "react";

const defaultTheme = createTheme();

export default function SignUp() {
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPass, setConfirmPass] = useState("");
  const navigate=useNavigate();
  const handleSubmit = async (e) => {
    e.preventDefault();

 
    if (!name.trim()) {
      alert("Name is required");
      return;
    }

  
    if (!email.trim()) {
      alert("Email is required");
      return;
    }

    
    if (password.length < 6) {
      alert("Password must be at least 6 characters long");
      return;
    }


    if (password !==confirmPass ) {
      alert("Passwords do not match");
      return;
    }

    try {
     
      const response = await axios.post("http://localhost:8081/api/v1/auth/register", {
        name: name,
        email:email,
        mobileNumber:phone,
        password: password,
        
      });

      console.log(response.data);  
      navigate("/dashboard/user");
    } catch (error) {
      console.error("Error during registration:", error);
    }
  };
  return (
    <div className="App">
      <Navbar secondary={true} />
      <ThemeProvider theme={defaultTheme}>
        <Grid container component="main" sx={{ height: "100vh" }}>
          <CssBaseline />
          <Grid
            item
            xs={false}
            sm={4}
            md={7}
            sx={{
              backgroundImage:
                "url(https://images.unsplash.com/photo-1460467820054-c87ab43e9b59?q=80&w=1967&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D)",
              backgroundRepeat: "no-repeat",
              backgroundColor: (t) =>
                t.palette.mode === "light"
                  ? t.palette.grey[50]
                  : t.palette.grey[900],
              backgroundSize: "cover",
              backgroundPosition: "center",
            }}
          />
          <Grid
            item
            xs={12}
            sm={8}
            md={5}
            component={Paper}
            elevation={6}
            square
          >
            <Box
              sx={{
                my: 8,
                mx: 4,
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
              }}
            >
              <Typography component="h1" variant="h5">
                Sign Up
              </Typography>
              <form
                onSubmit={handleSubmit}
              >
                <TextField
                  value={name}
                  onChange={(e) => {
                    setName(e.target.value);
                  }}
                  margin="normal"
                  required
                  fullWidth
                  id="name"
                  label="Name"
                  name="name"
                  autoComplete="name"
                  type="text"
                  autoFocus
                />
                <TextField
                  value={phone}
                  onChange={(e) => {
                    setPhone(e.target.value);
                  }}
                  margin="normal"
                  required
                  fullWidth
                  id="phone"
                  label="Phone Number"
                  name="phone"
                  autoComplete="phone"
                  type="number"
                  autoFocus
                />
                <TextField
                  value={email}
                  onChange={(e) => {
                    setEmail(e.target.value);
                  }}
                  margin="normal"
                  required
                  fullWidth
                  id="email"
                  label="Email Address"
                  name="email"
                  autoComplete="email"
                  type="email"
                  autoFocus
                />
                <TextField
                  value={password}
                  onChange={(e) => {
                    setPassword(e.target.value);
                  }}
                  margin="normal"
                  required
                  fullWidth
                  name="password"
                  label="Password"
                  type="password"
                  id="password"
                  autoComplete="current-password"
                />
                <TextField
                  value={confirmPass}
                  onChange={(e) => {
                    setConfirmPass(e.target.value);
                  }}
                  margin="normal"
                  required
                  fullWidth
                  name="confirm-password"
                  label="Confirm Password"
                  type="password"
                  id="confirm-password"
                  autoComplete="current-password"
                />
                <FormControlLabel
                  control={<Checkbox value="remember" color="primary" />}
                  label="Remember me"
                />
                <button
                  className="secondary-button button-fullwidth"
                  type="submit"
                >
                  Sign Up
                </button>
                <div>
                  <br />
                  <Link className="form-links" href="#" variant="body2">
                    Forgot password?
                  </Link>
                  <br />
                  <br />
                  <Link className="form-links" to="/signin" variant="body2">
                    {"Already have an account? Sign In"}
                  </Link>
                </div>
              </form>
            </Box>
          </Grid>
        </Grid>
      </ThemeProvider>
      <Footer />
    </div>
  );
}
