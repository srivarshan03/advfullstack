package com.example.event.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.event.entity.Applications;
import com.example.event.entity.User;
import com.example.event.repository.ApplicationRepository;
import com.example.event.service.ApplicationService;

@RestController
@RequestMapping("/api/applications")
public class ApplicationController {
    @Autowired
    private ApplicationService applicationService;

    @Autowired
    private ApplicationRepository applicationRepository;

    @GetMapping("/")
    public List<Applications> getApplications() {
        return applicationRepository.findAll();
    }

    @PostMapping("/{id}")
    public String createApplication(@RequestBody Applications application, @PathVariable int id) {
        return applicationService.createApplication(application, id);
    }

    @PostMapping("/approve/{id}")
    public String approve(@PathVariable Long id, @RequestHeader("amount") String amount,
            @RequestHeader("venue") String venue) {
        return applicationService.approve(id, amount, venue);
    }

    @PostMapping("/reject/{id}")
    public String reject(@PathVariable Long id) {
        return applicationService.reject(id);
    }

    @GetMapping("/users/{id}")
    public User getUser(@PathVariable Long id) {
        Applications application = applicationRepository.findById(id).orElse(null);
        return application.getUser();
    }
}
