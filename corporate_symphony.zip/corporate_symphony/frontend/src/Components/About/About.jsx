import AboutBackground from "../../Assets/images/about-removebg.png";

const About = () => {
  return (
    <div className="about-section-container">
      <div className="about-background-image-container">
        <img style={{height:"100vh"}} src={AboutBackground} alt="" />
      </div>
      <div className="about-section-image-container">
      </div>
      <div className="about-section-text-container">
        <p className="primary-subheading">About</p>
        <h1 className="primary-heading">
        Celebrate Victories!
        </h1>
        <p className="primary-text">
        Corporate Symphony is dedicated to delivering unparalleled corporate event management services that exceed expectations and leave a lasting impression. Our mission is to make the benefits of exceptional event experiences accessible to all businesses, regardless of size or industry.         </p>
      </div>
    </div>
  );
};

export default About;
