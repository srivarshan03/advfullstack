import BannerBackground from "../../Assets/images/party.jpg";
import Navbar from "../Navbar";
import { Link } from "react-router-dom";
import { FiArrowRight } from "react-icons/fi";

const Home = () => {
  return (
    <div className="home-container">
      <Navbar />
      <div className="home-banner-container">
        <div  style={{marginTop:100,marginRight:100}}  className="home-bannerImage-container">
          <img style={{borderRadius:100,height:"100vh"}} src={BannerBackground} alt="" />
        </div>
        <div className="home-text-section">
          <h1 className="primary-heading">Elevating Corporate Events to a Symphony of Success</h1>
          <p className="primary-text">
           Unveil the symphony of excellence behind every event we curate.
          </p>          
          <Link className="mobile-links" to={"/contact"}>
            <button className="secondary-button">
              <>
                Contact us <FiArrowRight />
              </>
            </button>
          </Link>
        </div>
        <div className="home-image-section">
        </div>
      </div>
    </div>
  );
};

export default Home;
